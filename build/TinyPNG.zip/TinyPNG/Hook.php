<?php

namespace Acms\Plugins\TinyPNG;

class Hook
{
    /**
     * メディアデータ作成
     * @param string $path 作成先パス
     *
     */
    public function mediaCreate($path)
    {

    }
}
